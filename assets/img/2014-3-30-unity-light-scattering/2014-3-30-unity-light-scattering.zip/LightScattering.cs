﻿using UnityEngine;
using System.Collections;
using System;

[RequireComponent(typeof(Camera))]

/// <summary>
/// light scattering (also called godrays) effect
/// <summary
public class LightScattering : MonoBehaviour {

    /// <summary>
    /// resource for light scattering effect
    /// </summary>
    public Light lightForScattering = null;
    public Shader objectOcclusionShader = null;
    public Shader lightRadiateShader = null;
    public Shader lightScatterShader = null;
    
    /// <summary>
    /// temp material
    /// </summary>
    private Material m_LightScatterMaterial = null;
    private Material m_LightRadiateMaterial = null;
    /// <summary>
    /// temp render texture
    /// </summary>
    private RenderTexture objectOcclusionTex = null;
    private RenderTexture lightRadiateTex = null;
    
    private int texHeight = 512;
    private bool isRenderDark = false;      // flag of render status

    /// <summary>
    /// params for light scattering effect
    /// </summary>
    [System.Serializable]
    public class Params
    {
        public float density = 1.0f;
        public float weight = 1.0f/32f;
        public float decay = 1.0f;
        public float exposure = 0.8f;
    }
    public Params parameters = new Params();

    /// <summary>
    /// light pos (x, y) in camera render texture, will be updated every frame
    /// </summary>
    private Vector4 lightPosInCamera = new Vector4(0, 0, 0, 1);

    /// <summary>
    /// status
    /// </summary>
    private bool isValid = false;

    void Awake()
    {
        CreateShader();
        isValid = CheckValid();
    }

    void CreateShader()
    {
        if (lightScatterShader == null)
            lightScatterShader = Shader.Find("Custom/LightScattering");
        if (lightRadiateShader == null)
            lightRadiateShader = Shader.Find("Custom/LightRadiate");
        if (objectOcclusionShader == null)
            objectOcclusionShader = Shader.Find("Custom/ObjectOcclusion");
    }

    bool CheckValid()
    {
        if (lightForScattering == null)
        {
            Debug.LogError("Light for scattering is null.");
            return false;
        }
        return true;
    }

	// Use this for initialization
	void Start () {
        if (!isValid)
            return;
	}

    // for debug, show intermediate result on screen
    void OnGUI()
    {
        if (lightRadiateTex != null)
            GUI.DrawTexture(new Rect(0.0f * Screen.width, 0.7f * Screen.height, 0.3f * Screen.width, 0.3f * Screen.height),
                lightRadiateTex, ScaleMode.ScaleToFit);

        if (objectOcclusionTex != null)
            GUI.DrawTexture(new Rect(0.3f * Screen.width, 0.7f * Screen.height, 0.3f * Screen.width, 0.3f * Screen.height),
               objectOcclusionTex, ScaleMode.ScaleToFit);
    }

	// Update is called once per frame
	void Update () {
        if (!isValid)
            return;

        // get light pos on screen
        lightPosInCamera = camera.WorldToViewportPoint(lightForScattering.transform.position);
        Color oldBackground = camera.backgroundColor;

        CreateTexture();

        // draw opaque object with dark color, draw transparent objects by alpha channel
        // object with alpha [0, 1] will transform to color [white, black]
        camera.backgroundColor = Color.white;       // set background to white
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.targetTexture = objectOcclusionTex;
        isRenderDark = true;
        camera.RenderWithShader(objectOcclusionShader, "RenderType");    // render object by the replace shader
        // reset
        isRenderDark = false;           
        camera.targetTexture = null;
        camera.clearFlags = CameraClearFlags.Skybox;
        camera.backgroundColor = oldBackground;
	}

    void OnRenderImage(RenderTexture src, RenderTexture dst)
    {
        if (isRenderDark)
        {
            Graphics.Blit(src, dst);
            return;
        }

        // disable scattering effect when light is out of screen
        Vector3 offset = lightForScattering.transform.position - transform.position;

        float angle = Vector3.Angle(transform.forward, offset);
        float fovFactor = camera.fieldOfView / 2;
        if (90 <= (angle + fovFactor))
        {
            Graphics.Blit(src, dst);
        }
        else
        {
            // lerp the exposure value by angle diff
            float dimWeight = 1-(Math.Max(angle, fovFactor) - fovFactor) / fovFactor;

            // draw a light radiate image, will occluded by objects rendered in objectDarkTex
            lightRadiateMaterial.SetVector("_LightPos", lightPosInCamera);
            lightRadiateMaterial.SetFloat("_LightRadius", 100);
            Graphics.Blit(objectOcclusionTex, lightRadiateTex, lightRadiateMaterial);

            // draw the finally effect
            Vector4 param = new Vector4(parameters.density, parameters.weight, parameters.decay, Mathf.Lerp(0, parameters.exposure, dimWeight));
            lightScatterMaterial.SetVector("_LightPos", lightPosInCamera);
            lightScatterMaterial.SetTexture("_LightRadTex", lightRadiateTex);
            lightScatterMaterial.SetVector("_Params", param);
            Graphics.Blit(src, dst, lightScatterMaterial);
        }

        ReleaseTexture();
    }

    protected Material lightRadiateMaterial
    {
        get
        {
            if (m_LightRadiateMaterial == null)
            {
                m_LightRadiateMaterial = new Material(lightRadiateShader);
                m_LightRadiateMaterial.hideFlags = HideFlags.HideAndDontSave;
            }
            return m_LightRadiateMaterial;
        }
    }

    protected Material lightScatterMaterial
    {
        get
        {
            if (m_LightScatterMaterial == null)
            {
                m_LightScatterMaterial = new Material(lightScatterShader);
                m_LightScatterMaterial.hideFlags = HideFlags.HideAndDontSave;
            }
            return m_LightScatterMaterial;
        }
    }

    // create temp textures to save intermediate render result
    void CreateTexture()
    {
        objectOcclusionTex = RenderTexture.GetTemporary((int)(texHeight * camera.aspect), texHeight, 16,
            RenderTextureFormat.ARGBFloat);
        lightRadiateTex = RenderTexture.GetTemporary(objectOcclusionTex.width, objectOcclusionTex.height, objectOcclusionTex.depth,
            objectOcclusionTex.format);
    }

    // release temp texture
    void ReleaseTexture()
    {
        RenderTexture.ReleaseTemporary(objectOcclusionTex);
        RenderTexture.ReleaseTemporary(lightRadiateTex);
    }

    void OnDisable()
    {
        DestroyImmediate(m_LightRadiateMaterial);
        DestroyImmediate(m_LightScatterMaterial);
    }
}
