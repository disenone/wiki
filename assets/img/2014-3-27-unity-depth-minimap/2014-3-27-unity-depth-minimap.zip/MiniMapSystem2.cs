﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Camera))]
[ExecuteInEditMode]
public class MiniMapSystem2 : MonoBehaviour
{
    /// <summary>
    /// setting
    /// </summary>
    public bool isFollowTarget = true;
    public bool isUseColorMap = true;
    public int mapResolution = 512;
    public string layerName = "mapsystem";
    private int layerInt = -1;

    /// <summary>
    /// resources for color, depth
    /// </summary>
    private RenderTexture colorTexture = null;
    private RenderTexture depthTexture = null;
    private Texture2D colorMap = null;
    public Shader depthShader = null;
    public Shader depthEdgeShader = null;
    public Shader mixShader = null;
    private Material m_MixMaterial = null;
    private Material m_DepthEdgeMaterial = null;

    /// <summary>
    /// target object
    /// </summary>
    public GameObject target = null;
    private Transform targetTransform;

    // bounds of all renderer
    private Bounds sceneBounds;
    private const float addHeight = 5F;

    /// <summary>
    /// status
    /// </summary>
    private bool isValid;
    private bool isRenderDepth;

    void Awake()
    {
        CalculateBounds();
        SetupCameraAndResources();

        isValid = CheckValid();
         if (!isValid)
             return;

        targetTransform = target.transform;
        
    }

    // Use this for initialization
    void Start()
    {
        if (!isValid)
            return;
    }

    bool CheckValid()
    {
        // check target
        if (target == null)
        {
            Debug.LogError("Target must not be null. Please add a target that is always centered on the minimap (e.g.: the character).");
            return false;
        }

        if (depthShader == null)
        {
            Debug.LogError("Render depth shader is null.");
            return false;
        }
        return true;
    }

    /// <summary>
    /// setup camera, shaders, color map
    /// </summary>
    void SetupCameraAndResources()
    {
        layerInt = LayerMask.NameToLayer(layerName);

        // setup camera
        if (camera == null)
            return;
        camera.depth = 50;
        camera.aspect = 1;
        camera.orthographic = true;
        camera.orthographicSize = 20;
        camera.rect = new Rect(0.0f, 0f, 1f, 1f);
        camera.nearClipPlane = addHeight - 1;
        camera.farClipPlane = sceneBounds.size.y + addHeight*2;
        camera.transform.forward = Vector3.down;
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.depthTextureMode = DepthTextureMode.DepthNormals;

        // create shader
        if (depthShader == null)
            depthShader = Shader.Find("Custom/DepthByReplaceShader");
        if (depthEdgeShader == null)
            depthEdgeShader = Shader.Find("Custom/DepthColorEdge");
        if (mixShader == null)
            mixShader = Shader.Find("Custom/ColorMixDepth");
        
        // depth color map
        colorMap = Resources.Load<Texture2D>("colormap");
        if (colorMap == null)
            Debug.LogError("colormap is null");
    }

    /// <summary>
    /// for debug, show result on screen
    /// </summary>
    void OnGUI()
    {
        if (!isValid)
            return;
        //GUI.depth = 0;
        if(colorTexture != null)
            GUI.DrawTexture(new Rect(0.0f * Screen.width, 0.0f * Screen.height, 0.3f * Screen.width, 0.3f * Screen.height),
               colorTexture);
        if(depthTexture != null)
            GUI.DrawTexture(new Rect(0.3f * Screen.width, 0.0f * Screen.height, 0.3f * Screen.width, 0.3f * Screen.height),
               depthTexture);
    }

    void Update()
    {
        if (!isValid)
            return;

        // update position
        if (isFollowTarget)
            camera.transform.position = GetCurrentCameraPos();

        CreateTexture();

        // set cull mask not render objects in layer mapsystem, not use now
//         int oldMask = camera.cullingMask;
//         camera.cullingMask = 1 << layerInt;
        camera.targetTexture = depthTexture;
        isRenderDepth = true;
        // render depth
        camera.RenderWithShader(depthShader, "");
        isRenderDepth = false;
//        camera.cullingMask = oldMask;
        camera.targetTexture = colorTexture;

    }

    /// <summary>
    /// render depth edge effect, also render the finally effect(depth edge + real scene color)
    /// </summary>
    /// <param name="src"></param>
    /// <param name="dst"></param>
    void OnRenderImage(RenderTexture src, RenderTexture dst)
    {
        // if now rendering depth map
        if (isRenderDepth)
        {
            depthEdgeMaterial.SetTexture("_DepthTex", src);
            if(isUseColorMap)
                Graphics.Blit(src, dst, depthEdgeMaterial);
            else
                Graphics.Blit(src, dst);
            return;
        }
        // else rendering real color scene, mix the real color with depth map
        else
        {
            mixMaterial.SetTexture("_MainTex", src);
            mixMaterial.SetTexture("_DepthTex", depthTexture);
            Graphics.Blit(src, dst, mixMaterial);
            ReleaseTexture();
        }
    }

    void CreateTexture()
    {
        colorTexture = RenderTexture.GetTemporary(mapResolution, mapResolution, 16, RenderTextureFormat.ARGBFloat);
        depthTexture = RenderTexture.GetTemporary(mapResolution, mapResolution, 16, RenderTextureFormat.ARGBFloat);
    }

    void ReleaseTexture()
    {
        RenderTexture.ReleaseTemporary(colorTexture);
        RenderTexture.ReleaseTemporary(depthTexture);
    }

    protected Material mixMaterial
    {
        get
        {
            if (m_MixMaterial == null)
            {
                m_MixMaterial = new Material(mixShader);
                m_MixMaterial.hideFlags = HideFlags.HideAndDontSave;
            }
            return m_MixMaterial;
        }
    }

    protected Material depthEdgeMaterial
    {
        get
        {
            if (m_DepthEdgeMaterial == null)
            {
                m_DepthEdgeMaterial = new Material(depthEdgeShader);
                m_DepthEdgeMaterial.SetTexture("_ColorMap", colorMap);
                m_DepthEdgeMaterial.hideFlags = HideFlags.HideAndDontSave;
            }
            return m_DepthEdgeMaterial;
        }
    }

    void OnDisable()
    {
        DestroyImmediate(m_MixMaterial);
        DestroyImmediate(m_DepthEdgeMaterial);
    }

    Vector3 GetCurrentCameraPos()
    {
        return new Vector3(targetTransform.position.x, GetTerrainHeight(), targetTransform.position.z);
    }

    float GetTerrainHeight()
    {
        return sceneBounds.max.y + addHeight;
    }

    /// <summary>
    /// calculate bounds of scene, output error if not bounds exist
    /// </summary>
    private void CalculateBounds()
    {
        Bounds? bounds = null;
        // get terrains bounds
        Terrain[] terrains = GameObject.FindObjectsOfType<Terrain>();
        if (terrains != null)
        {
            foreach (Terrain terrain in terrains)
            {
                if (!terrain.gameObject.activeSelf)
                    continue;
                if (bounds == null)
                    bounds = GetTerrainBounds(terrain);
                else
                {
                    var newBounds = GetTerrainBounds(terrain);
                    if (newBounds.HasValue)
                        bounds.Value.Encapsulate(newBounds.Value);
                }
            }
        }

        // get all renderer bounds
        Renderer[] renderers = UnityEngine.Object.FindObjectsOfType(typeof(Renderer)) as Renderer[];
        if (renderers != null)
        {
            foreach (Renderer renderer in renderers)
            {
                // do not add self
                if (renderer.gameObject.layer == layerInt)
                    continue;
                // only use stuff on the layers 
                if (bounds == null)
                    bounds = renderer.bounds;
                else
                    bounds.Value.Encapsulate(renderer.bounds);                
            }
        }

        if (bounds.HasValue)
            sceneBounds = bounds.Value;
        else
            Debug.LogError("Could not find terrain nor any other bounds in scene");
    }

    /// <summary>
    /// get bounds of terrain, if not exist, return null
    /// </summary>
    /// <param name="terrain"></param>
    /// <returns></returns>
    Bounds? GetTerrainBounds(Terrain terrain)
    {
        var meshRenderer = terrain.GetComponent<MeshRenderer>();
        if (meshRenderer != null)
        {
            return meshRenderer.bounds;
        }
        else
        {
            var collider = terrain.GetComponent<TerrainCollider>();
            if (collider != null)
            {
                return collider.bounds;
            }
            else
            {
                return null;
            }
        }
    }
}
